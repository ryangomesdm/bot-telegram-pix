# Bot Telegram com Pix via PushinPay

## Como rodar na Render

1. Vá em https://render.com
2. Clique em 'New Web Service'
3. Escolha 'Repositório Git Público'
4. Cole o link do GitHub
5. Configure:
- Build Command: pip install -r requirements.txt
- Start Command: python main.py
6. Configure as variáveis de ambiente:
- BOT_TOKEN
- PUSHINPAY_API_KEY
7. Clique em Deploy.

Pronto! Seu bot estará online 24 horas.
